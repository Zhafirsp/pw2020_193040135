 <?php

	// menghubungkan dengan file php lainnya
	require 'php/functions.php';

	// melakukan query
	$apparel = query("SELECT * FROM apparel");

	//ketika tombol cari di klik
	if (!empty($_GET['cari'])) {
		$keyword = $_GET['keyword'];
		$apparel = query("SELECT * FROM apparel WHERE 
              nama_barang LIKE '%$keyword%' OR
              merk LIKE '%$keyword%'");
	} else {
		$apparel = query("SELECT * FROM apparel");
	}
	?>
 <!DOCTYPE html>
 <html lang="en">

 <head>
 	<meta charset="UTF-8">
 	<title>Tugas Besar</title>
 	<!-- my CSS -->
 	<link rel="stylesheet" href="css/style.css">
 	<!--Import Google Icon Font-->
 	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 	<!--Import materialize.css-->
 	<link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />
 	<!--Let browser know website is optimized for mobile-->
 	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
 	<!-- icon -->
 	<link rel="icon" href="assets/img/Logo.png">
 </head>

 <body id="home" class="scrollspy">
 	<!-- navbar -->
 	<div class="navbar-fixed">
 		<nav class="black">
 			<div class="container">
 				<div class="nav-wrapper">
 					<a href="#!"><img src="assets/img/f.png" style="width: 65px;"></a>
 					<a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
 					<ul class="right hide-on-med-and-down">
 						<li>
 							<form action="" method="POST">
 								<input type="text" name="keyword" placeholder="Masukan keyword pencarian" autocomplete="off" autofocus class="keyword" style="color: white">
 								<button type="submit" name="cari" class="tombol-cari">cari</button>
 							</form>
 						</li>
 						<li><a href="../../index.php">Home</a></li>
 						<li><a href="#catalog">Catalog</a></li>
 						<li><a href="#brand">Brand</a></li>
 						<li><a href="php/login.php">Halaman Admin</li>
 					</ul>
 				</div>
 			</div>
 		</nav>
 	</div>

 	<!-- sidenav -->
 	<ul class="sidenav black" id="mobile-nav">
 		<li>
 			<div class="user-view">
 				<div class="background">
 					<img src="assets/img/z.jpg">
 				</div>
 				<a href="#user"><img class="circle rounded" src="assets/img/as.png"></a>
 				<a href="#name"><span class="white-text name">Muhammad Zhafir Sunandy Pramana</span></a>
 				<a href="#email"><span class="white-text email">zhafirsp@gmail.com</span></a>
 			</div>
 			<a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">home</i></a>
 		</li>
 		<li><a href="../../index.php" class="white-text">Home</a></li>
 		<li><a href="#catalog" class="white-text">Catalog</a></li>
 		<li><a href="#brand" class="white-text">Brand</a></li>
 		<li>
 			<form action="" method="GET">
 				<input type="text" name="keyword" placeholder="Masukan keyword pencarian" autocomplete="off" autofocus class="keyword" style="color: white">
 				<button type="submit" name="cari" class="tombol-cari">cari</button>
 			</form>
 		</li>
 	</ul>
 	<!-- parallax -->
 	<div class="slider">
 		<ul class="slides">
 			<li>
 				<img src="assets/img/z.jpg">
 				<div class="caption left-align">
 					<h2 class="text-lighten-3">Selamat Datang di Halaman <span class="light red-text">Index</span> Saya.</h2>
 				</div>
 			</li>
 			<li>
 				<img src="assets/img/z.jpg">
 				<div class="caption right-align">
 					<h2 class="text-lighten-3"><span class="light red-text">Mahasiswa</span>Yang Berasal Dari <span class="light blue-text">Kota Hujan </span> <span class="light red-text">Bogor.</span></h2>
 				</div>
 			</li>
 			<li>
 				<img src="assets/img/z.jpg">
 				<div class="caption center-align">
 					<h2 class="text-lighten-3"> Yang Motonya <br><span class="light black-text">Lerne </span><span class="light red-text">Leiden</span> <span class="light black-text">Ohne zu</span> <span class="light red-text">Klagen!.</span></h2>
 				</div>
 			</li>
 			<li>
 				<img src="assets/img/z.jpg">
 				<div class="caption">
 					<h2 class="text-lighten-3"> Yang Artinya <br><span class="light red-text">Belajar </span><span class="light black-text">Menderita</span> <span class="light red-text">Tanpa</span> <span class="light black-text">Mengeluh!.</span></h2>
 				</div>
 			</li>
 		</ul>
 	</div>
 	<hr>

 	<section id="catalog" class="scrollspy">
 		<h3 class="center">Menu</h3>
 		<div class="underline-title-index"></div>
 		<div class="col m6 s12 ">
 			<div class="container">
 				<table class="highlight responsive-table centered">
 					<?php if (empty($apparel)) : ?>
 						<tbody>
 							<tr>
 								<td colspan="7">
 									<h1>Data tidak ditemukan</h1>
 								</td>
 							</tr>
 						<?php else : ?>
 							<div class="row">
 								<?php $i = 1; ?>
 								<?php foreach ($apparel as $brg) : ?>
 									<div class="col s12 m3">
 										<div class="card" style="height:500px; width:auto;">
 											<div class="card-image">
 												<img src="assets/img/<?= $brg['foto']; ?>" class="foto materialboxed">
 												<a class="link btn-floating halfway-fab waves-effect waves-light red" href="php/detail.php?no=<?= $brg['no'] ?>"><i class=" material-icons">details</i></a>
 											</div>
 											<div class="card-content">
 												<p class="nama">
 													<a class="link" href="php/detail.php?no=<?= $brg['no'] ?>">
 														<?= $brg["nama_barang"] ?>
 													</a>
 												</p>
 											</div>
 										</div>
 									</div>
 								<?php endforeach; ?>
 							</div>
 						<?php endif; ?>
 						</tbody>
 				</table>
 			</div>
 		</div>
 	</section>
 	<div id="brand" class="parallax-container scrollspy">
 		<div class="parallax black"><img src="assets/img/a.jpg"></div>
 		<div class="container">
 			<div class="row">
 				<h2 class="text-lighten-3"><span class="light red-text"> Brand</span></h2>
 				<div class="col m2 s2 center"><img src="assets/logo/ysl.png"></div>
 				<div class="col m3 s3 center"><img src="assets/logo/bbc.png"></div>
 				<div class="col m2 s2 center"><img src="assets/logo/conv.png"></div>
 				<div class="col m3 s3 center"><img src="assets/logo/nike.png"></div>
 				<div class="col m2 s2 center"><img src="assets/logo/sd.png"></div>
 			</div>
 			<div class="row">
 				<div class="col m3 s3 center"><img src="assets/logo/phillip.png"></div>
 				<div class="col m3 s3 center"><img src="assets/logo/qs.png"></div>
 				<div class="col m3 s3 center"><img src="assets/logo/vet.png"></div>
 				<div class="col m3 s3 center"><img src="assets/logo/mango.png"></div>
 			</div>
 		</div>
 	</div>


 	<div class="fixed-action-btn">
 		<a class="btn-floating btn-large red">
 			<i class="medium material-icons">info</i>
 		</a>
 		<ul>
 			<li> <a href="#home" class="btn-floating orange"> <i class="material-icons">arrow_back</i></a></li>
 			<li><a class="btn-floating red"><i class="material-icons" href="tel:+6282213302003">call</i>Call</a></li>
 			<li><a class="btn-floating yellow darken-1" href="mailto:zhafirsp@gmail.com?subject=Subject atau judul disini" target="_blank"><i class="material-icons">mail</i>Email</a></li>
 			<li><a class="btn-floating green" href="https://wa.me/6282213302003" target="_blank"><i class="material-icons">phone_in_talk</i>whatsapp</a></li>
 			<li><a class="btn-floating blue" href="#home"><i class="material-icons">arrow_upward</i></a></li>
 		</ul>
 	</div>

 	<!-- footer -->
 	<footer class="page-footer light black white-text">
 		<div class="container">
 			<div class="row">
 				<div class="col l4 m4 s12">
 					<h5 class="white-text">IKUTI KAMI</h5>
 					<ul>
 						<li><a class="grey-text text-lighten-3" href="#!">INSTAGRAM</a></li>
 						<li><a class="grey-text text-lighten-3" href="#!">FACEBOOK</a></li>
 						<li><a class="gre31y-text text-lighten-3" href="#!">TWITTER</a></li>
 						<li><a class="grey-text text-lighten-3" href="#!">PINTEREST</a></li>
 					</ul>
 				</div>
 				<div class="col l4 m4 s12">
 					<h5 class="white-text">PERUSAHAAN</h5>
 					<ul>
 						<li><a class="grey-text text-lighten-3" href="#!">TENTANG KAMI</a></li>
 						<li><a class="grey-text text-lighten-3" href="#!">KANTOR</a></li>
 						<li><a class="grey-text text-lighten-3" href="#!">TOKO</a></li>
 					</ul>
 				</div>
 				<div class="col l4 m4 s12">
 					<h5 class="white-text">KEBIJAKAN</h5>
 					<ul>
 						<li><a class="grey-text text-lighten-3" href="#!">KEBIJAKAN PRIVASI</a></li>
 						<li><a class="grey-text text-lighten-3" href="#!">SYARAT MEMBELI</a></li>
 					</ul>
 				</div>
 			</div>
 		</div>
 		<div class="footer-copyright">
 			<div class="container">
 				© 2014 Muhammad Zhafir Sunandy Pramana, All rights reserved.
 				<a class="grey-text text-lighten-4 right" href="#!">Indonesia |</a> <a class="grey-text text-lighten-4 right" href="#!">English</a>
 			</div>
 		</div>
 	</footer>

 	<!--JavaScript-->
 	<script type="text/javascript" src="js/materialize.min.js"></script>
 	<script type="text/javascript" src="js/script.js"></script>


 </body>

 </html>